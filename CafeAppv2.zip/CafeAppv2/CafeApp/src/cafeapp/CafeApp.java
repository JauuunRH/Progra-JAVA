package cafeapp;

import java.util.Scanner;

public class CafeApp {

    public static void main(String[] args) {
        int opc;
        Cafeteria Cafe;
        Cafe = new Cafeteria();
        do {
            System.out.println("Menu Cafeteria");
            System.out.println("1. Productos");
            System.out.println("2. Ventas");
            System.out.println("9. Salir");
            opc = Opcion();
            switch (opc) {
                case 1:
                    MenuProductos(Cafe);
                    break;
                case 2:
                    MenuVentas(Cafe);
                    break;
            }
        } while (opc != 9);

    }

    public static void MenuVentas(Cafeteria c) {
        int opc;
        do {
            System.out.println("Menu Ventas");
            System.out.println("1. Crear venta");
            System.out.println("2. Listar venta");
            System.out.println("9. Regresar");
            opc = Opcion();
            switch (opc) {
                case 1:
                    CrearVentas(c);
                    break;
                case 2:
                    ListarVentas(c);
                    break;
            }
        } while (opc != 9);
    }

    public static void ListarVentas(Cafeteria c) {
        int NumVentas, NumProd, Cant;
        int i, j;
        Venta V;
        VentaProducto Vp;
        NumVentas = c.getNumVentas();
        for (i = 0; i < NumVentas; i++) {
            V = c.getVenta(i);
            NumProd = V.getNumProductos();
            System.out.println("Venta:" + V.getIdVenta() + " Fecha:" + V.getFecha());
            for (j = 0; j < NumProd; j++) {
                Vp = V.getProducto(j);
                System.out.println("\tNombre:" + Vp.getIdProducto().getNombre() + " Cantidad:" + Vp.getCantidad());

            }
        }


    }

    public static void CrearVentas(Cafeteria c) {
        int opc, index, cant;
        String fecha;
        Venta V;
        V = new Venta();
        index = c.getNumVentas();
        V.setIdVenta(index);
        System.out.println("Ingrese fecha:");
        fecha = Info();
        V.setFecha(fecha);


        do {
            System.out.println("Menu crear ventas");
            System.out.println("1. Listar Productos");
            System.out.println("2. Agregar producto al carrito");
            System.out.println("3. Listar carrito");
            System.out.println("4. Realizar venta");
            System.out.println("5. Cancelar venta");
            opc = Opcion();
            switch (opc) {
                case 1:
                    ListarProducto(c);
                    break;
                case 2:
                    AgregarProductoCarrito(V, c);
                    break;
                case 3:
                    ListarCarrito(V);
                    break;
                case 4:
                    c.addVenta(V);
                    opc = 9;
                    break;
                case 5:
                    opc = 9;
                    break;
            }
        } while (opc != 9);
    }

    public static void ListarCarrito(Venta V) {
        int i, cant, NumPro;
        String Nombre, Cantidad, descripcion;
        NumPro = V.getNumProductos();
        for (i = 0; i < NumPro; i++) {
            Producto P;
            VentaProducto Vp = V.getProducto(i);
            P = Vp.getIdProducto();
            System.out.println(i + " " + P.getNombre() + "\t" + P.getDescripcion() + "\t" + Vp.getCantidad());
        }

    }

    public static void AgregarProductoCarrito(Venta V, Cafeteria C) {
        int index, cant;
        Producto P;
        System.out.println("Ingrese ID del producto:");
        index = Opcion();
        System.out.println("Ingrese cantidad:");
        cant = Opcion();
        P = C.getProducto(index);
        VentaProducto Vp;
        Vp = new VentaProducto();
        Vp.setIdProducto(P);
        Vp.setCantidad(cant);
        V.addProducto(Vp);
    }

    public static void MenuProductos(Cafeteria c) {
        int opc;
        do {
            System.out.println("Menu producto");
            System.out.println("1. Agregar productos");
            System.out.println("2. Listar productos");
            System.out.println("3. Editar producto");
            System.out.println("4. Eliminar producto");
            System.out.println("9. regresar");
            opc = Opcion();
            switch (opc) {
                case 1:
                    AgregarProducto(c);
                    break;
                case 2:
                    ListarProducto(c);
                    break;
                case 3:
                    EditarProducto(c);
                    break;
                case 4:
                    EliminarProducto(c);
                    break;
            }
        } while (opc != 9);
    }

    public static void AgregarProducto(Cafeteria C) {
        String Nombre, Descripcion;
        System.out.println("Ingresa nombre del producto:");
        Nombre = Info();
        System.out.println("Ingresa descripción");
        Descripcion = Info();
        Producto Aux;
        Aux = new Producto();
        Aux.setNombre(Nombre);
        Aux.setDescripcion(Descripcion);
        C.addProducto(Aux);
    }

    public static void EditarProducto(Cafeteria C) {
        String Nombre, Descripcion;
        Producto Aux;
        int Num;
        ListarProducto(C);
        System.out.println("Selecciona un producto:");
        Num = Opcion();
        Aux = C.getProducto(Num);
        if (Aux != null) {
            System.out.println("Ingresa nombre:");
            Nombre = Info();
            System.out.println("Ingresa descripcion:");
            Descripcion = Info();
            Aux.setNombre(Nombre);
            Aux.setDescripcion(Descripcion);
        }
    }

    public static void ListarProducto(Cafeteria C) {
        int NumProd, i;
        Producto p;
        System.out.println("Listado de producto en inventario");
        NumProd = C.getNumProductos();
        for (i = 0; i < NumProd; i++) {
            p = C.getProducto(i);
            System.out.println(i + " " + p.toString());
        }
    }

    public static void EliminarProducto(Cafeteria C) {
        int index;
        Producto P;
        ListarProducto(C);
        System.out.println("Selecciona un Producto:");
        index = Opcion();
        P = C.getProducto(index);
        if (P != null) {
            C.eliminarProducto(index);
        }

    }

    public static int Opcion() {
        Scanner Teclado;
        Teclado = new Scanner(System.in);
        return Teclado.nextInt();
    }

    public static String Info() {
        Scanner Teclado;
        Teclado = new Scanner(System.in);
        return Teclado.nextLine();
    }

    public static double Real() {
        Scanner Teclado;
        Teclado = new Scanner(System.in);
        return Teclado.nextDouble();
    }
}
