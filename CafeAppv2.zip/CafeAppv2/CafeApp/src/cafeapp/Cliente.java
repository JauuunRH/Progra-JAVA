package cafeapp;

public class Cliente {

    String Nombre;
    String PComprado;


}
