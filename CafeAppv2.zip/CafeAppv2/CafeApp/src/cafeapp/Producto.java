package cafeapp;


public class Producto {
    String Nombre;
    String Descripcion;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }
    
    @Override
    public String toString(){
        String Prod;
        Prod="Nombre:"+Nombre+" Descripcion:"+Descripcion;
        return Prod;
    }
    
}
