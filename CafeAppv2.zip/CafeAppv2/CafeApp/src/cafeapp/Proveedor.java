package cafeapp;


public class Proveedor {
   String Nombre;
   
   
}
