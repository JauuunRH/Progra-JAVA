
package cafeapp;

import java.util.ArrayList;

public class Venta {
    ArrayList <VentaProducto> Ventas;
    int idVenta;
    String Fecha;
    
    
    Venta(){
        Ventas=new ArrayList();
    }
    
    void addProducto(VentaProducto V)
    {
        Ventas.add(V);
    }
    
    public int getNumProductos(){
        return Ventas.size();
    }
    
    public VentaProducto getProducto(int index){
        return Ventas.get(index);
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }
    
    
    
}
