package cafeapp;

public class VentaProducto {
    Producto IdProducto;
    int Cantidad;

    public Producto getIdProducto() {
        return IdProducto;
    }

    public void setIdProducto(Producto IdProducto) {
        this.IdProducto = IdProducto;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }
    
}
