/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practicapartido;

import java.util.ArrayList;

/**
 *
 * @author sala11
 */
public class EQUIPO {
    private String Nombre;
    private String Tecnico;
    private String Dueno;
    private int PosicionTable;
    private ArrayList <JUGADOR> Jugadores;
    private ArrayList <PARTIDO> Partidos;
    
    public void AgregarJugador(JUGADOR J){
        Jugadores.add(J);
    }
    public void AgregarJugador(JUGADOR J, EQUIPO E){
        AgregarJugador(J);
        E.AgregarJugador(J);
    }
    
    public void AgregarPartido(PARTIDO P){
        Partidos.add(P);
    }

    public String getDueno() {
        return Dueno;
    }

    public void setDueno(String Dueno) {
        this.Dueno = Dueno;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getPosicionTable() {
        return PosicionTable;
    }

    public void setPosicionTable(int PosicionTable) {
        this.PosicionTable = PosicionTable;
    }

    public String getTecnico() {
        return Tecnico;
    }

    public void setTecnico(String Tecnico) {
        this.Tecnico = Tecnico;
    }
    
}
