/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practicapartido;

/**
 *
 * @author sala11
 */
public class JUGADOR {
    private String Nombre;
    private int Numero;
    private int Posicion;
    
    
}
