/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practicapartido;

import java.util.ArrayList;

/**
 *
 * @author sala11
 */
public class LIGA {
    private String Nombre;
    private ArrayList <EQUIPO> Equipos;
    private ArrayList <JUGADOR> Jugadores;
    private ArrayList <PARTIDO> Partidos;
    
    public void AgregarPartido(PARTIDO P){
        Partidos.add(P);
    }
    public void AgregarPartido(EQUIPO Local, EQUIPO Visitante){
        PARTIDO P;
        P=new PARTIDO();
        //sobrecarga de metodos
        P.setLocal(Local);
        P.setVisitante(Visitante);
        Partidos.add(P);
        //integridad referencial
        Local.AgregarPartido(P);
        Visitante.AgregarPartido(P);
        
    }
    public void AgregarJugador(JUGADOR P){
        Jugadores.add(P);
    }
    public void AgregarEquipo(EQUIPO E){
        Equipos.add(E);
    }
    
    //
    public int ObtenerNumJugadores(){
        return Jugadores.size();
    }
    public int ObtenerNumPartidos(){
        return Partidos.size();
    }
    public int ObtenerEquipo(){
        return Equipos.size();
    }
    
    
    
    //Agregar Valores
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    
}
