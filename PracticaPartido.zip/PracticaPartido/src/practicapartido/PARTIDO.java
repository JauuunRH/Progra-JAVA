/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practicapartido;

/**
 *
 * @author sala11
 */
public class PARTIDO {
    private EQUIPO Local;
    private EQUIPO Visitante;
    private int GolesL;
    private int GolesV;
    private boolean Jugado;

    public int getGolesL() {
        return GolesL;
    }

    public void setGolesL(int GolesL) {
        this.GolesL = GolesL;
    }

    public int getGolesV() {
        return GolesV;
    }

    public void setGolesV(int GolesV) {
        this.GolesV = GolesV;
    }

    public boolean isJugado() {
        return Jugado;
    }

    public void setJugado(boolean Jugado) {
        this.Jugado = Jugado;
    }

    public EQUIPO getLocal() {
        return Local;
    }

    public void setLocal(EQUIPO Local) {
        this.Local = Local;
    }

    public EQUIPO getVisitante() {
        return Visitante;
    }

    public void setVisitante(EQUIPO Visitante) {
        this.Visitante = Visitante;
    }
    
    
}
