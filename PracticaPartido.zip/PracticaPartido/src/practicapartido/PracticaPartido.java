/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practicapartido;

/**
 *
 * @author sala11
 */
public class PracticaPartido {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
